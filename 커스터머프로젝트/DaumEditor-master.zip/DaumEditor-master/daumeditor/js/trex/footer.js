try {
    EditorJSLoader.readyState = 'complete';
    EditorJSLoader.finish();
} catch(e) {
}